<?php

// Define o usuário e senha
$login = 'login';
$senha = 'senha';

// Opções de configurações do cliente WSDL
$options = array(
    'soap_version' => SOAP_1_2,
    'login' => $login,
    'password' => $senha
);

// Cria o objeto SOAP com a URL do serviço
$client = new SoapClient("http://cradf.cra21.com.br/cradf/xml/protestos.php?wsdl", $options);

// Exemplo de chamada do método para recepção de confirmação
$retornoXml = $client->Confirmacao('C0013110.141');

echo $retornoXml;